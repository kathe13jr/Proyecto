import { Component } from '@angular/core';

@Component({
  selector: 'app-sliders',
  standalone: true,
  imports: [],
  templateUrl: './sliders.component.html',
  styleUrl: './sliders.component.css'
})
export class SlidersComponent {

}

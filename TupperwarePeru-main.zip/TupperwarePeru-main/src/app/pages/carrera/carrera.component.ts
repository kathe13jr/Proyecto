import { Component } from '@angular/core';

@Component({
  selector: 'app-carrera',
  standalone: true,
  imports: [],
  templateUrl: './carrera.component.html',
  styleUrl: './carrera.component.css'
})
export class CarreraComponent {

}
